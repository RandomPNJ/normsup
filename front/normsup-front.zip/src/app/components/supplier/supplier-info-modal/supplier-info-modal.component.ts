import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier-info-modal',
  templateUrl: './supplier-info-modal.component.html',
  styleUrls: ['./supplier-info-modal.component.scss']
})
export class SupplierInfoModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
