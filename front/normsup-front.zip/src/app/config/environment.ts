// Application configuration

export const Configuration = {
  DEFINE_CAR : '/api/product/define_car',
  DEFINE_PRODUCT: '/api/product/define_product',
  DEFINE_REQUIREMENT: '/api/csr/define_requirement',
  serverUrl:  'http://localhost:8080',
  basicRoutesRoles: ['ADMIN', 'USER']
};
